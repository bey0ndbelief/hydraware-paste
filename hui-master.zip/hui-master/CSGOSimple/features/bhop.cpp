#include "bhop.hpp"
#include "../options.hpp"

#include "../valve_sdk/csgostructs.hpp"
#include "../helpers/math.hpp"
#include <filesystem>
#include "../helpers/prediction.hpp"

void BunnyHop::OnCreateMove(CUserCmd* cmd)
{
  static bool jumped_last_tick = false;
  static bool should_fake_jump = false;
  if (!g_Options.misc_bhop2)
	  return;
  if (!g_LocalPlayer)
	  return;

  if (!g_LocalPlayer->IsAlive())
	  return;

  if (g_LocalPlayer->m_nMoveType() == MOVETYPE_LADDER || g_LocalPlayer->m_nMoveType() == MOVETYPE_NOCLIP)
	  return;

  if (g_LocalPlayer->m_fFlags() & FL_INWATER)
	  return;

  if(!jumped_last_tick && should_fake_jump) {
    should_fake_jump = false;
    cmd->buttons |= IN_JUMP;
  } else if(cmd->buttons & IN_JUMP) {
    if(g_LocalPlayer->m_fFlags() & FL_ONGROUND) {
      jumped_last_tick = true;
      should_fake_jump = true;
    } else {
      cmd->buttons &= ~IN_JUMP;
      jumped_last_tick = false;
    }
  } else {
    jumped_last_tick = false;
    should_fake_jump = false;
  }
}
void BunnyHop1::PastedMovementCorrection(CUserCmd* cmd, QAngle old_angles, QAngle wish_angle)
{// pasted from only god knows where
	if (old_angles.pitch != wish_angle.pitch || old_angles.yaw != wish_angle.yaw || old_angles.roll != wish_angle.roll)
	{
		Vector wish_forward, wish_right, wish_up, cmd_forward, cmd_right, cmd_up;

		auto viewangles = old_angles;
		auto movedata = Vector(cmd->forwardmove, cmd->sidemove, cmd->upmove);
		viewangles.Normalize();

		if (!(g_LocalPlayer->m_fFlags() & FL_ONGROUND) && viewangles.yaw != 0.f)
			movedata.y = 0.f;

		Math::AngleVectors(wish_angle, wish_forward, wish_right, wish_up);
		Math::AngleVectors(wish_angle, wish_forward, wish_right, wish_up);


		auto v8 = sqrt(wish_forward.x * wish_forward.x + wish_forward.y * wish_forward.y), v10 = sqrt(wish_right.x * wish_right.x + wish_right.y * wish_right.y), v12 = sqrt(wish_up.z * wish_up.z);

		Vector wish_forward_norm(1.0f / v8 * wish_forward.x, 1.0f / v8 * wish_forward.y, 0.f),
			wish_right_norm(1.0f / v10 * wish_right.x, 1.0f / v10 * wish_right.y, 0.f),
			wish_up_norm(0.f, 0.f, 1.0f / v12 * wish_up.z);

		auto v14 = sqrt(cmd_forward.x * cmd_forward.x + cmd_forward.y * cmd_forward.y), v16 = sqrt(cmd_right.x * cmd_right.x + cmd_right.y * cmd_right.y), v18 = sqrt(cmd_up.z * cmd_up.z);

		Vector cmd_forward_norm(1.0f / v14 * cmd_forward.x, 1.0f / v14 * cmd_forward.y, 1.0f / v14 * 0.0f),
			cmd_right_norm(1.0f / v16 * cmd_right.x, 1.0f / v16 * cmd_right.y, 1.0f / v16 * 0.0f),
			cmd_up_norm(0.f, 0.f, 1.0f / v18 * cmd_up.z);

		auto v22 = wish_forward_norm.x * movedata.x, v26 = wish_forward_norm.y * movedata.x, v28 = wish_forward_norm.z * movedata.x, v24 = wish_right_norm.x * movedata.y, v23 = wish_right_norm.y * movedata.y, v25 = wish_right_norm.z * movedata.y, v30 = wish_up_norm.x * movedata.z, v27 = wish_up_norm.z * movedata.z, v29 = wish_up_norm.y * movedata.z;

		Vector correct_movement;
		correct_movement.x = cmd_forward_norm.x * v24 + cmd_forward_norm.y * v23 + cmd_forward_norm.z * v25 + (cmd_forward_norm.x * v22 + cmd_forward_norm.y * v26 + cmd_forward_norm.z * v28) + (cmd_forward_norm.y * v30 + cmd_forward_norm.x * v29 + cmd_forward_norm.z * v27);
		correct_movement.y = cmd_right_norm.x * v24 + cmd_right_norm.y * v23 + cmd_right_norm.z * v25 + (cmd_right_norm.x * v22 + cmd_right_norm.y * v26 + cmd_right_norm.z * v28) + (cmd_right_norm.x * v29 + cmd_right_norm.y * v30 + cmd_right_norm.z * v27);
		correct_movement.z = cmd_up_norm.x * v23 + cmd_up_norm.y * v24 + cmd_up_norm.z * v25 + (cmd_up_norm.x * v26 + cmd_up_norm.y * v22 + cmd_up_norm.z * v28) + (cmd_up_norm.x * v30 + cmd_up_norm.y * v29 + cmd_up_norm.z * v27);

		static ConVar* cl_forwardspeed = g_CVar->FindVar("cl_forwardspeed");

		if (cl_forwardspeed == nullptr)
			return;

		static ConVar* cl_sidespeed = g_CVar->FindVar("cl_sidespeed");

		if (cl_sidespeed == nullptr)
			return;

		static ConVar* cl_upspeed = g_CVar->FindVar("cl_upspeed");

		if (cl_upspeed == nullptr)
			return;
		// get max speed limits by convars
		const float flMaxForwardSpeed = cl_forwardspeed->GetFloat();
		const float flMaxSideSpeed = cl_sidespeed->GetFloat();
		const float flMaxUpSpeed = cl_upspeed->GetFloat();

		correct_movement.x = std::clamp(correct_movement.x, -flMaxForwardSpeed, flMaxForwardSpeed);
		correct_movement.y = std::clamp(correct_movement.y, -flMaxSideSpeed, flMaxSideSpeed);
		correct_movement.z = std::clamp(correct_movement.z, -flMaxUpSpeed, flMaxUpSpeed);

		cmd->forwardmove = correct_movement.x;
		cmd->sidemove = correct_movement.y;
		cmd->upmove = correct_movement.z;

		cmd->buttons &= ~(IN_MOVERIGHT | IN_MOVELEFT | IN_BACK | IN_FORWARD);
		if (cmd->sidemove != 0.0) {
			if (cmd->sidemove <= 0.0)
				cmd->buttons |= IN_MOVELEFT;
			else
				cmd->buttons |= IN_MOVERIGHT;
		}

		if (cmd->forwardmove != 0.0) {
			if (cmd->forwardmove <= 0.0)
				cmd->buttons |= IN_BACK;
			else
				cmd->buttons |= IN_FORWARD;
		}
	}
}
void BunnyHop1::EdgeBug(CUserCmd* pCmd, QAngle& angView)
{// this method of doing it is kinda autistic and I know the code is a bit of clusterfuck but whatever
	if (!GetAsyncKeyState(g_Options.smart_edge_bug_key))
		return;


	if (iFlagsBackup & FL_ONGROUND)
		return; // imagine trying to edgebug while we on the ground lol (protip: u cunt)

	bShouldEdgebug = flZVelBackup < -flBugSpeed && round(g_LocalPlayer->m_vecVelocity().z) == -round(flBugSpeed) && g_LocalPlayer->m_nMoveType() != MOVETYPE_LADDER;
	if (bShouldEdgebug) // we literally boutta bug on da edge lol
		return;

	int nCommandsPredicted = g_Prediction->Split->nCommandsPredicted;

	// backup original stuff that we change so we can restore later if no edgebug detek
	QAngle angViewOriginal = angView;
	QAngle angCmdViewOriginal = pCmd->viewangles;
	int iButtonsOriginal = pCmd->buttons;
	Vector vecMoveOriginal;
	vecMoveOriginal.x = pCmd->sidemove;
	vecMoveOriginal.y = pCmd->forwardmove;

	// static static static static static
	static Vector vecMoveLastStrafe;
	static QAngle angViewLastStrafe;
	static QAngle angViewOld = angView;
	static QAngle angViewDeltaStrafe;
	static bool bAppliedStrafeLast = false;
	if (!bAppliedStrafeLast)
	{// we didn't strafe last time so it's safe to update these, if we did strafe we don't want to change them ..
		angViewLastStrafe = angView;
		vecMoveLastStrafe = vecMoveOriginal;
		angViewDeltaStrafe = (angView - angViewOld);
		angViewDeltaStrafe;
	}
	bAppliedStrafeLast = false;
	angViewOld = angView;

	for (int t = 0; t < 4; t++)
	{

		if (m_prediction_type)
		{
			t = m_prediction_type;
			m_prediction_type = 0;
		}
		PredictionSystem::Get().RestoreEntityToPredictedFrame(nCommandsPredicted - 1); // reset player to before engine prediction was ran (-1 because this whole function is only called after pred in cmove)
		if (iButtonsOriginal& IN_DUCK&& t < 2) // if we already unducking then don't unduck pusi
			t = 2;
		bool bApplyStrafe = !(t % 2); // t == 0 || t == 2
		bool bApplyDuck = t > 1;

		// set base cmd values that we need
		pCmd->viewangles = angViewLastStrafe;
		pCmd->buttons = iButtonsOriginal;
		pCmd->sidemove = vecMoveLastStrafe.x;
		pCmd->forwardmove = vecMoveLastStrafe.y;

		for (int i = 0; i < g_Options.smart_edge_bug_ticks; i++)
		{
			// apply cmd changes for prediction
			if (bApplyDuck)
				pCmd->buttons |= IN_DUCK;
			else
				pCmd->buttons &= ~IN_DUCK;
			if (bApplyStrafe)
			{
				pCmd->viewangles += angViewDeltaStrafe;
				pCmd->viewangles.Normalize();
				pCmd->viewangles.Clamp();
			}
			else
			{
				pCmd->sidemove = 0.f;
				pCmd->forwardmove = 0.f;
			}
			// run prediction
			PredictionSystem::Get().StartPrediction(pCmd);
			PredictionSystem::Get().EndPrediction();
			// check if we'd edgebug
			bShouldEdgebug = flZVelBackup < -flBugSpeed && round(g_LocalPlayer->m_vecVelocity().z) == -round(flBugSpeed) && g_LocalPlayer->m_nMoveType() != MOVETYPE_LADDER;
			flZVelBackup = g_LocalPlayer->m_vecVelocity().z;


			/* da feet at */
			if (bShouldEdgebug)
			{// !!!EDGEBUG DETEKTET!!!
				iEdgebugButtons = pCmd->buttons; // backup iButtons state
				if (bApplyStrafe)
				{// if we hit da bug wit da strafe we gotta make sure we strafe right
					bAppliedStrafeLast = true;
					angView = (angViewLastStrafe + angViewDeltaStrafe);
					angView.Normalize();
					angView.Clamp();
					angViewLastStrafe = angView;
					pCmd->sidemove = vecMoveLastStrafe.x;
					pCmd->forwardmove = vecMoveLastStrafe.y;
				}
				/* restore angViewPoint back to what it was, we only modified it for prediction purposes
				*  we use movefix instead of changing angViewPoint directly
				*  so we have pSilent pEdgebug (perfect-silent; prediction-edgebug) ((lol))
				*/
				pCmd->viewangles = angCmdViewOriginal;
				m_prediction_ticks = i;
				m_prediction_type = t;
				return;
			}

			if (g_LocalPlayer->m_fFlags() & FL_ONGROUND || g_LocalPlayer->m_nMoveType() == MOVETYPE_LADDER)
				break;
		}
	}

	/* if we got this far in the function then we won't hit an edgebug in any of the predicted scenarios
	*  so we gotta restore everything back to what it was originally
	*/
	pCmd->viewangles = angCmdViewOriginal;
	angView = angViewOriginal;
	pCmd->buttons = iButtonsOriginal;
	pCmd->sidemove = vecMoveOriginal.x;
	pCmd->forwardmove = vecMoveOriginal.y;
}
void BunnyHop::AutoStafe(CUserCmd* cmd)
{
	if (!g_Options.autostrafe)
		return;

	if (g_LocalPlayer->m_fFlags() & FL_ONGROUND)
		return;

	static auto side = 1.f;
	side = -side;

	auto velocity = g_LocalPlayer->m_vecVelocity();

	QAngle wish_angle = cmd->viewangles;

	auto speed = velocity.Length2D();
	auto ideal_strafe = std::clamp(RAD2DEG(atan(15.f / speed)), 0.f, 90.f);

	cmd->forwardmove = 0.f;

	static auto cl_sidespeed = g_CVar->FindVar("cl_sidespeed");

	static float old_yaw = 0.f;
	auto yaw_delta = std::remainderf(wish_angle.yaw - old_yaw, 360.f);
	auto abs_yaw_delta = abs(yaw_delta);
	old_yaw = wish_angle.yaw;

	const auto cl_sidespeed_value = cl_sidespeed->GetFloat();

	if (abs_yaw_delta <= ideal_strafe || abs_yaw_delta >= 30.f)
	{
		QAngle velocity_direction;
		Math::VectorAngles(velocity, velocity_direction);
		auto velocity_delta = std::remainderf(wish_angle.yaw - velocity_direction.yaw, 360.0f);
		auto retrack = std::clamp(RAD2DEG(atan(30.f / speed)), 0.f, 90.f) * 2.f;
		if (velocity_delta <= retrack || speed <= 15.f)
		{
			if (-retrack <= velocity_delta || speed <= 15.0f)
			{
				wish_angle.yaw += side * ideal_strafe;
				cmd->sidemove = cl_sidespeed_value * side;
			}
			else
			{
				wish_angle.yaw = velocity_direction.yaw - retrack;
				cmd->sidemove = cl_sidespeed_value;
			}
		}
		else
		{
			wish_angle.yaw = velocity_direction.yaw + retrack;
			cmd->sidemove = -cl_sidespeed_value;
		}

		Math::CorrectMovement(cmd, wish_angle, cmd->viewangles);
	}
	else if (yaw_delta > 0.f)
		cmd->sidemove = -cl_sidespeed_value;
	else
		cmd->sidemove = cl_sidespeed_value;
}
template<class T>
static T* FindHudElement(const char* name) //get hud so we can post in chat
{
	static auto pThis = *reinterpret_cast<DWORD**>(Utils::PatternScan(GetModuleHandleW(L"client.dll"), "B9 ? ? ? ? E8 ? ? ? ? 8B 5D 08") + 1);

	static auto find_hud_element = reinterpret_cast<DWORD(__thiscall*)(void*, const char*)>(Utils::PatternScan(GetModuleHandleW(L"client.dll"), "55 8B EC 53 8B 5D 08 56 57 8B F9 33 F6 39 77 28"));
	return (T*)find_hud_element(pThis, name);
}
bool edgebugged = false; //edgebug bool
int edgebugs = 1; //amount of edge bugs
void BunnyHop1::PrePred(CUserCmd* pCmd)
{
	// gotta backup the flags before prediction for jumpbug (and edgejump if u want that)
	iFlagsBackup = g_LocalPlayer->m_fFlags();
	// gotta backup dat z vel
	flZVelBackup = g_LocalPlayer->m_vecVelocity().z;

	if (bShouldEdgebug) // if we predicted an edgebug while crouching last tick then crouch again (mainly to reduce weird crouchspam shit)
		pCmd->buttons = iEdgebugButtons;

	static ConVar* sv_gravity = g_CVar->FindVar("sv_gravity");
	flBugSpeed = (sv_gravity->GetFloat() * 0.5f * g_GlobalVars->interval_per_tick); // fun fact: edgebug falling speed is half a tick worth of gravity (i think lol)

	static float flZVelPrev = flZVelBackup;
	bShouldEdgebug = flZVelPrev < -flBugSpeed && round(g_LocalPlayer->m_vecVelocity().z) == -round(flBugSpeed) && g_LocalPlayer->m_nMoveType() != MOVETYPE_LADDER;
	flZVelPrev = flZVelBackup;

	if (bShouldEdgebug && g_Options.smart_edge_bug && GetAsyncKeyState(g_Options.smart_edge_bug_key) && g_Options.smart_edge_bug_indicator)
	{// indicator shit
		g_LocalPlayer->HealthShotBoost() = g_GlobalVars->curtime + 1;
		//I::Surface->PlaySoundSurface(XorStr("buttons\\blip1.wav"));
		auto niggeros = "";
		if (g_LocalPlayer->m_fFlags() & FL_DUCKING)
			niggeros = "ducking type | ";
		else
			niggeros = "standing type | ";

		auto g_ChatElement = FindHudElement<CHudChat>("CHudChat");
		g_ChatElement->ChatPrintf(0, 0, std::string("").
			append("\x09").
			append("$ vamp1r.tk $").
			append("| edgebugged | ").
			append(std::to_string(m_prediction_ticks)).
			append("/").
			append(std::to_string(g_Options.smart_edge_bug_ticks)).
			append(" ticks | ").
			append(std::to_string(m_prediction_type)).
			append(" mode | ").
			append(niggeros).
			append(std::to_string(edgebugs)).
			append("times").
			c_str());

	}

	// reset feet box indicators if we're on ground, nice to look at where your actual feet collider is when standing on stuff

}