#pragma once
#include "../helpers/math.hpp"
#include "../singleton.hpp"
class C_BasePlayer;
class CUserCmd;

namespace BunnyHop 
{
    void OnCreateMove(CUserCmd* cmd);
    void AutoStafe(CUserCmd* cmd);

}
class BunnyHop1 : public Singleton<BunnyHop1>
{
public:
	// Get

	void EdgeBug(CUserCmd* pCmd, QAngle& angView);
	void PastedMovementCorrection(CUserCmd* cmd, QAngle old_angles, QAngle wish_angle);
	/* bug on da edge or nuh? */
	bool bShouldEdgebug;

	// Movement
	/* backup of player flags before prediction */
	//int iFlagsBackup;
	/* backup of player z velocity before prediction */
	//float flZVelBackup;
	/* da speeda da bug */
//	float flBugSpeed;
	/* backup of our edgebug buttons */
	//int iEdgebugButtons;
//	int  m_prediction_ticks = 0;
//	int  m_prediction_type = 0;
	void PrePred(CUserCmd* pCmd);
	/* bug on da edge or nuh? */

	/* where they at tho? */

private:
	// Movement
	int iFlagsBackup;
	/* backup of player z velocity before prediction */
	float flZVelBackup;
	/* da speeda da bug */
	float flBugSpeed;
	/* backup of our edgebug buttons */
	int iEdgebugButtons;
	int m_prediction_ticks;
	int m_prediction_type;

};