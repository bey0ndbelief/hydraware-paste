#pragma once

#include "..//valve_sdk/sdk.hpp"
#include "..//valve_sdk/csgostructs.hpp"
#include "../singleton.hpp"

class PredictionSystem : public Singleton<PredictionSystem> {
public:
	PredictionSystem();

	void StartPrediction(CUserCmd* cmd);
	void EndPrediction();
	void RestoreEntityToPredictedFrame(int predicted_frame);
private:
	float m_flOldCurtime;
	float m_flOldFrametime;
	CMoveData m_MoveData;

	int* m_pPredictionRandomSeed;
};